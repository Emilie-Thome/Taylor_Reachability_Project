#include "tadiff.h"
#include <iostream>
using namespace std;
using namespace fadbad;

class Toy
{
public:
	T<double> x;          // Independent variables
	T<double> xp;         // Dependent variables
	Toy()
	{
	// record DAG at construction:
		xp = -x;
	}
	void reset()
	{
		xp.reset();
	}
};

int main()
{
	// Construct ODE:
	Toy ode;

	// Set point of expansion:
	ode.x[0]=1;

	int i;
	for(i=0;i<10;i++)
	{
	// Evaluate the i'th Taylor coefficient of
	// the r.h.s. of the ODE:
		ode.xp.eval(i);

	// Since d(x,y,z,p)/dt=lorenz(x,y,z,p) we have
		ode.x[i+1]=ode.xp[i]/point(double(i+1));
	}

	// Print out the Taylor coefficients for the solution
	// of the ODE:
	for(i=0;i<=10;i++)
	{
		cout << "x[" << i << "]=" << ode.x[i] << endl;
	}

	return 0;
}
